<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Test View</title>
    </head>
    <body>
        <h1><?php echo $data ?></h1>
    </body>
</html>